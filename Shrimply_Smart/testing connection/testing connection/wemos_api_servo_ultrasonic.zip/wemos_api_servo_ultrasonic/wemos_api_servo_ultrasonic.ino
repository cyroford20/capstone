#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <SoftwareSerial.h>

// Wi-Fi
const char* ssid = "YOTC-4F17BE";
const char* pass = "hni574b6";

// Web server (API only)
ESP8266WebServer server(80);

// Serial link to Arduino (matches your wiring):
//   Arduino D2 (RX) <- WeMos D13/SCK (D5 / GPIO14)  [WeMos TX]
//   Arduino D3 (TX) -> WeMos D12/MISO (D6 / GPIO12) [WeMos RX]
//   GND <-> GND
SoftwareSerial link(D6, D5); // RX, TX

String lastDistance = "NA";
String lastServo = "OFF";

static void sendCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.sendHeader("Cache-Control", "no-store");
}

static void handleOptions() {
  sendCorsHeaders();
  server.send(204);
}

static void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
  WiFi.begin(ssid, pass);

  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print('.');

    if (millis() - start > 20000) {
      Serial.println();
      Serial.println("WiFi timeout, retrying...");
      start = millis();
      WiFi.disconnect();
      WiFi.begin(ssid, pass);
    }
  }
  Serial.println();
}

static void apiDistance() {
  sendCorsHeaders();
  server.send(200, "text/plain", lastDistance);
}

static void apiServoState() {
  sendCorsHeaders();
  server.send(200, "text/plain", lastServo);
}

static void apiServoOn() {
  link.println("S=ON");
  lastServo = "ON";
  sendCorsHeaders();
  server.send(200, "text/plain", "OK");
}

static void apiServoOff() {
  link.println("S=OFF");
  lastServo = "OFF";
  sendCorsHeaders();
  server.send(200, "text/plain", "OK");
}

static void apiPing() {
  sendCorsHeaders();
  server.send(200, "text/plain", "PONG");
}

static void handleRoot() {
  // No embedded UI; just a hint.
  sendCorsHeaders();
  server.send(200, "text/plain",
              "WeMos API only. Use /api/distance, /api/servo, /api/servo/on, /api/servo/off");
}

static void readArduinoLines() {
  while (link.available()) {
    String line = link.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;

    if (line.startsWith("D=")) {
      String v = line.substring(2);
      v.trim();
      lastDistance = v;
      Serial.print("Distance: ");
      Serial.println(lastDistance);
    } else if (line.startsWith("ACK=")) {
      String v = line.substring(4);
      v.trim();
      if (v.length() > 0) lastServo = v;
      Serial.print("Servo ACK: ");
      Serial.println(lastServo);
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(600);

  Serial.println();
  Serial.println("WEMOS API BOOT");
  Serial.println("Serial Monitor must be 115200");
  Serial.print("Reset reason: ");
  Serial.println(ESP.getResetReason());

  // Stabilize SoftwareSerial RX
  pinMode(D6, INPUT_PULLUP);

  link.begin(9600);
  link.setTimeout(30);

  connectWiFi();

  Serial.print("WeMos IP: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);

  server.on("/api/ping", HTTP_OPTIONS, handleOptions);
  server.on("/api/ping", HTTP_GET, apiPing);

  server.on("/api/distance", HTTP_OPTIONS, handleOptions);
  server.on("/api/distance", HTTP_GET, apiDistance);

  server.on("/api/servo", HTTP_OPTIONS, handleOptions);
  server.on("/api/servo", HTTP_GET, apiServoState);

  server.on("/api/servo/on", HTTP_OPTIONS, handleOptions);
  server.on("/api/servo/on", HTTP_GET, apiServoOn);

  server.on("/api/servo/off", HTTP_OPTIONS, handleOptions);
  server.on("/api/servo/off", HTTP_GET, apiServoOff);

  server.begin();

  Serial.println("API ready.");
}

void loop() {
  server.handleClient();
  readArduinoLines();
}
