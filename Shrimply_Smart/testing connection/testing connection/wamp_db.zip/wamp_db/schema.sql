-- Create database + table for distance + servo state logging

CREATE DATABASE IF NOT EXISTS shrimp_db;
USE shrimp_db;

CREATE TABLE IF NOT EXISTS readings (
  id INT NOT NULL AUTO_INCREMENT,
  distance_cm FLOAT NULL,
  servo_state ENUM('ON','OFF') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);
