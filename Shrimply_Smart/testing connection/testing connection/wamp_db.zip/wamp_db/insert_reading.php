<?php
// insert_reading.php
// Inserts a single reading into your EXISTING database/table:
//   DB:    srimply-smart
//   Table: apifeedinglog
//   Cols:  servoOnOrOff, distance
//
// Accepts POST (preferred names):
//   - servoOnOrOff = ON|OFF (or 1|0)
//   - distance     = number or NA
//   - api_key      = optional
//
// Also accepts old/compat names:
//   - servo_state  (same as servoOnOrOff)
//   - distance_cm  (same as distance)

header('Content-Type: application/json; charset=utf-8');

// --- CONFIG ---
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'srimply-smart';
$TABLE   = 'apifeedinglog';

// Optional: set to '' to disable key checking.
$API_KEY = 'shrimp-key-123';

function fail($code, $msg) {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg]);
  exit;
}

$apiKey = $_POST['api_key'] ?? '';
if ($API_KEY !== '' && $apiKey !== $API_KEY) {
  fail(401, 'bad api_key');
}

$servoRaw = $_POST['servoOnOrOff'] ?? ($_POST['servo_state'] ?? '');
$servo = strtoupper(trim((string)$servoRaw));
if ($servo === '1') $servo = 'ON';
if ($servo === '0') $servo = 'OFF';
if ($servo !== 'ON' && $servo !== 'OFF') {
  fail(400, 'servoOnOrOff must be ON or OFF');
}

$distanceRaw = trim((string)($_POST['distance'] ?? ($_POST['distance_cm'] ?? '')));
$distance = null;
if ($distanceRaw === '' || strtoupper($distanceRaw) === 'NA') {
  $distance = null;
} else {
  if (!is_numeric($distanceRaw)) {
    fail(400, 'distance must be numeric or NA');
  }
  $distance = floatval($distanceRaw);
}

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_error) {
  fail(500, 'db connect failed');
}

$sql = 'INSERT INTO `'.$TABLE.'` (`servoOnOrOff`, `distance`) VALUES (?, ?)';
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
  fail(500, 'prepare failed');
}

// bind_param does not accept NULL for 'd' well; bind as string and use NULL via separate query.
if ($distance === null) {
  $stmt->close();
  $sql2 = 'INSERT INTO `'.$TABLE.'` (`servoOnOrOff`, `distance`) VALUES (?, NULL)';
  $stmt2 = $mysqli->prepare($sql2);
  if (!$stmt2) fail(500, 'prepare failed');
  $stmt2->bind_param('s', $servo);
  if (!$stmt2->execute()) fail(500, 'execute failed');
  $id = $stmt2->insert_id;
  $stmt2->close();
} else {
  // Store servo first, then distance
  $stmt->bind_param('sd', $servo, $distance);
  if (!$stmt->execute()) fail(500, 'execute failed');
  $id = $stmt->insert_id;
  $stmt->close();
}

$mysqli->close();

echo json_encode(['ok' => true, 'id' => $id, 'servoOnOrOff' => $servo, 'distance' => $distance]);
