<?php
// get_latest.php

header('Content-Type: application/json; charset=utf-8');

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'srimply-smart';
$TABLE   = 'apifeedinglog';

// Change this if your table doesn't have an id column.
$ORDER_BY = 'id';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_error) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'db connect failed']);
  exit;
}

$q = 'SELECT `servoOnOrOff`, `distance` FROM `'.$TABLE.'` ORDER BY `'.$ORDER_BY.'` DESC LIMIT 1';
$res = $mysqli->query($q);
if (!$res) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'query failed', 'hint' => 'Check table name/columns and ORDER_BY in get_latest.php']);
  exit;
}

$row = $res->fetch_assoc();
$res->free();
$mysqli->close();

echo json_encode(['ok' => true, 'latest' => $row]);
